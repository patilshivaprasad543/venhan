import React, { useState } from "react";
import Diagram from './components/Diagram';
import Sidebar from './components/Sidebar';
import "./App.css";

const App = () => {
  const [nodes, setNodes] = useState([
    {
      id: "1",
      type: "default",
      data: { label: "Node 1" },
      position: { x: 100, y: 100 },
    },
    {
      id: "2",
      type: "default",
      data: { label: "Node 2" },
      position: { x: 400, y: 300 },
    },
  ]);
  const [edges, setEdges] = useState([
    { id: "e1-2", source: "1", target: "2", animated: true },
  ]);

  return (
    <div className="app-container">
      <Sidebar
        nodes={nodes}
        edges={edges}
        setNodes={setNodes}
        setEdges={setEdges}
      />
      <Diagram
        nodes={nodes}
        edges={edges}
        setNodes={setNodes}
        setEdges={setEdges}
      />
    </div>
  );
};

export default App;
