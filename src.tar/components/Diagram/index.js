import React from "react";
import ReactFlow, { addEdge, Background } from "react-flow-renderer";
import "./index.css";

const Diagram = ({ nodes, edges, setNodes, setEdges }) => {
  const onConnect = (params) => setEdges((eds) => addEdge(params, eds));

  return (
    <div className="diagram">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={(changes) =>
          setNodes((nds) =>
            nds.map((node) => ({
              ...node,
              ...changes.find((c) => c.id === node.id),
            }))
          )
        }
        onEdgesChange={(changes) =>
          setEdges((eds) =>
            eds.filter((edge) => !changes.some((c) => c.id === edge.id))
          )
        }
        onConnect={onConnect}
        fitView
      >
        <Background variant="dots" gap={12} size={1} />
      </ReactFlow>
    </div>
  );
};

export default Diagram;
