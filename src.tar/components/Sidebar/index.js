import React, { useState } from "react";
import "./index.css";

const Sidebar = ({ nodes, edges, setNodes, setEdges }) => {
  const [newNode, setNewNode] = useState({ id: "", label: "", x: 0, y: 0 });

  const addNode = () => {
    setNodes((nds) => [
      ...nds,
      {
        id: newNode.id,
        type: "default",
        data: { label: newNode.label },
        position: { x: newNode.x, y: newNode.y },
      },
    ]);
    setNewNode({ id: "", label: "", x: 0, y: 0 });
  };

  return (
    <div className="sidebar">
      <h3>Manage Nodes and Edges</h3>
      <div>
        <h4>Add Node</h4>
        <input
          placeholder="ID"
          value={newNode.id}
          onChange={(e) => setNewNode({ ...newNode, id: e.target.value })}
        />
        <input
          placeholder="Label"
          value={newNode.label}
          onChange={(e) => setNewNode({ ...newNode, label: e.target.value })}
        />
        <input
          placeholder="X Position"
          type="number"
          value={newNode.x}
          onChange={(e) =>
            setNewNode({ ...newNode, x: parseInt(e.target.value, 10) })
          }
        />
        <input
          placeholder="Y Position"
          type="number"
          value={newNode.y}
          onChange={(e) =>
            setNewNode({ ...newNode, y: parseInt(e.target.value, 10) })
          }
        />
        <button onClick={addNode}>Add Node</button>
      </div>
    </div>
  );
};

export default Sidebar;
